package com.example.gngappv1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
